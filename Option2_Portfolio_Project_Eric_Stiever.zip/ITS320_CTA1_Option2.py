#------------------------------------------------------------------------
# Program Name: 
# Program Objective:
#------------------------------------------------------------------------
# Program Name: Eric Stiever's Option 2 Assignment
# Program Objective:
# Logic used (Pseudocode or just plain English):
# Program Inputs: The first line contains the first integer. The second line contains the second integer.
# Read the first integer entered by the user.
num_1 = int(input('Please enter a number: '))
# Read the second integer entered by the user.
num_2 = int(input('Please enter another number: '))
#------------------------------------------------------------------------
# Program Outputs:
print(num_1//num_2) # Integer division
print(num_1/num_2) # Float division
print(num_1 % num_2) # Modulo division
#------------------------------------------------------------------------

